/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package oop.projicet.mo;

import java.sql.SQLException;

/**
 *
 * @author user
 */
public class WaterTank {
    private int level;
    WaterTank(int level) throws SQLException, ClassNotFoundException{
        this.level = new DataBase().logcountwater();
    }
    int getLevel() throws SQLException, ClassNotFoundException{
        return new DataBase().logcountwater();
    }
    void setLevel(int level){
        this.level = level;
    }
    void drain(int amount){
        this.level -= amount;
    }
    void fill(){
        this.level = 3000;
    }
    boolean check(int amount) throws WaterException{
        if(level < amount){
             throw new WaterException("No water in machine ");
        }
        return true;
    }
}
