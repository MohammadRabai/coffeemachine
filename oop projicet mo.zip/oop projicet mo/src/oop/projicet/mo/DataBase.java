/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package oop.projicet.mo;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.ResultSet;
/**
 *
 * @author usar
 */
public class DataBase implements Logger{
    private PreparedStatement statement;
    private Connection conn ;
    
    public DataBase () throws SQLException {
        this.conn = DriverManager.getConnection("jdbc:mysql://localhost/coffee","root", "");
    }

    /**
     *
     * @param nameCoffee
     * @param water
     * @param beans
     * @param coffean
     * @throws ClassNotFoundException
     * @throws SQLException
     */
    @Override
     public void log(String nameCoffee , int water , int beans , float coffean)throws ClassNotFoundException , SQLException, ClassNotFoundException, ClassNotFoundException{
          Class.forName("com.mysql.jdbc.Driver");
          String sql = "Insert Info coffee (coffeename , water , beans , coffean) VALUES (? , ? , ? , ?)" ;
          this.statement = conn.prepareStatement(sql);
          statement.setString(1 , nameCoffee);
          statement.setInt(2 , water);
          statement.setInt(3 , beans);
          statement.setFloat(4 , coffean);
          statement.executeUpdate();
          if (statement != null) {
              statement.close();
          }
          if (conn != null){
              conn.close();
          }
      }
      public int logcountcup() throws ClassNotFoundException , SQLException{
        
            Class.forName("com.mysql.jdbc.Driver");
            String sql = "select count(coffeename) as cups from coffee";
            statement = conn.prepareStatement(sql);
            ResultSet  result = statement.executeQuery(sql);
            int count = 0 ;
            while(result.next()){
                count = result.getInt("cups");
            }
            conn.close();
            return count;
        
          
      }
      public int logcountwater() throws ClassNotFoundException , SQLException{
          Class.forName("com.mysql.jdbc.Driver");
          String sql = "select waterafter as maxx from coffee where  id = (select max(id) from coffee)";
          statement = conn.prepareStatement(sql);
          ResultSet result = statement.executeQuery(sql);
          int count = 0;
          while(result.next()){
              count = result.getInt("maxx");
          }
          conn.close();
          return count;
      }
      
      public int logcountbeans() throws ClassNotFoundException , SQLException{
          Class.forName("com.mysql.jdbc.Driver");
          String sql = "select beansafter as maxx from coffee where  id = (select max(id) from coffee)";
          statement = conn.prepareStatement(sql);
          ResultSet result = statement.executeQuery(sql);
          int count = 0;
          while(result.next()){
              count = result.getInt("maxx");
          }
          conn.close();
          return count;
      }
      public float logcoffean() throws ClassNotFoundException , SQLException{
          Class.forName("com.mysql.jdbc.Driver");
          String sql = "select coffean as maxx from coffee where  id = (select max(id) from coffee)";
          statement = conn.prepareStatement(sql);
          ResultSet result = statement.executeQuery(sql);
          int count = 0;
          while(result.next()){
              count = result.getInt("maxx");
          }
          conn.close();
          return count;
      }
    
}
