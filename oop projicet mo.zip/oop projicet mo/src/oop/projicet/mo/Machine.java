/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package oop.projicet.mo;

import java.sql.SQLException;
import java.util.ArrayList;

/**
 *
 * @author user
 */
public class Machine {
    private WaterTank water;
    private BeansTank beans;
    private WasteTray clean;
    private Grinder grinder;
    private int count ;
    private Coffee coffe;
    private Logger logger;
    Machine() throws SQLException, ClassNotFoundException{
        water = new WaterTank(5000);
        beans = new BeansTank(2500);
        clean = new WasteTray(100);
        grinder = new  Grinder();
        logger = new DataBase();
        
    }
    WaterTank Water(){
        return water;
    }
    BeansTank Beans(){
        return beans;
    }
    WasteTray Clean(){
        return clean;
    }
    int countCup() throws ClassNotFoundException, SQLException{
        return logger.logcountcup();
        
    }
    public String makeCoffee(String nameCoffee , int waterAmount , int beansAmount, int grind, int notclean) throws ClassNotFoundException, SQLException{
        coffe = new Coffee(beansAmount, waterAmount);
        grinder.grind();
        grinder.purWater();
        water.drain(waterAmount);
        beans.drain(beansAmount);
        clean.waste(notclean);
        logger.log(nameCoffee, waterAmount, beansAmount, coffe.getCaffeine());
        return "name: "+nameCoffee +", Caffeine: "+coffe.getCaffeine();
        
    }
}
