/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package oop.projicet.mo;

import java.sql.SQLException;

/**
 *
 * @author user
 */
public class BeansTank {
    private int level;
    BeansTank(int level) throws SQLException, ClassNotFoundException{
        this.level = new DataBase().logcountbeans();
    }
    int getLevel() throws SQLException, ClassNotFoundException{
        return new DataBase().logcountbeans();
    }
    void setLevel(int level){
        this.level = level;
    }
    void drain(int amount){
        this.level -= amount;
    }
    void fill(){
        this.level = 1000;
    }
    boolean check(int amount) throws BeansException{
        if(level < amount){
             throw new BeansException("No Beans in Machine");
        }
        return true;
    }
}
