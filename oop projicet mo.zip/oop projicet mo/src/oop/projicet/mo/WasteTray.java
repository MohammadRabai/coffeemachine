/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package oop.projicet.mo;

/**
 *
 * @author user
 */
public class WasteTray {
    private int level;
    WasteTray(int level){
        this.level = level;
    }
    int getLevel(){
        return level;
    }
    void setLevel(int level){
        this.level = level;
    }
    void waste(int amount){
        this.level -= amount;
    }
    void clean(){
        this.level = 100;
    }
    boolean check(int amount) throws TrayException{
        if(level < amount){
             throw new TrayException("please clean machine");
        }
        return true;
    }
}
